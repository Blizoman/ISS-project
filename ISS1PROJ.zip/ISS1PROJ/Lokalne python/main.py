#### #### #### #### #### #### #### ####
#### MADE by xblizna00 FIT VUT ISS #### 
#### #### #### #### #### #### #### ####


import os
import numpy as np
import soundfile as sf
from scipy.signal import find_peaks
from collections import defaultdict
import time
import matplotlib.pyplot as plt


LOGIN = "xblizna00" 
Fs = 16000
# ==========================================
# DATA LOADING
# ==========================================
def load_data(S, dirname, count, no_samples):
    for i in range(count):
        path = os.path.join(dirname, f"{i}.wav")
        try:
            data, sample_rate = sf.read(path)
            if len(data) > no_samples:
                S[i] = data[:no_samples]
            else:
                S[i, :len(data)] = data
        except Exception as e:
            print(f"Errorito {path}: {e}")

# ==========================================
# PARAMETRE A SPRACOVANIE 
# ==========================================
frame_size_sec = 0.064      
jump_size_sec = 0.032       
samples = int(Fs * frame_size_sec) 
jump = int(Fs * jump_size_sec) 

# Obycajny spektrogram
def get_spectrogram(signal, samples, jump):
    frames = []               
    start = 0                 
    while ((start + samples) <= (len(signal))):
        frames.append(signal[start : (start + samples)])
        start += jump
    frames = np.array(frames) 

    window = np.hanning(samples)  
    for i in range(len(frames)):  
        frames[i] = frames[i] * window

    N_samples = 2048                              
    spectrogram = np.fft.rfft(frames, n = N_samples, axis = 1)
    spectrogram = np.abs(spectrogram) 
    spectrogram[:, :20] = 0
    spectrogram[:, 600:] = 0
    return spectrogram
# logaritmicky spektrogram
def spec_to_spec_log(spectrogram):
    not_zero = 0.000000000000001      
    return np.log(spectrogram + not_zero)
# hladanie maxim
def search_peaks(spectrogram):
    peaks = []
    for time in range(spectrogram.shape[0]):
        peaky_peaks, _ = find_peaks(spectrogram[time], height=np.max(spectrogram[time])*0.5)
        for frequency in peaky_peaks:
            peaks.append((frequency, time))
    return peaks
# hashovacia fce
def make_hash(peaks):
    hashes = []
    neighbors = 5
    n_peaks = len(peaks)          
    for i in range(n_peaks):      
        for j in range(1, neighbors+1):
            if i + j < n_peaks:       
                freq1 = peaks[i][0] 
                freq2 = peaks[i + j][0] 
                time1 = peaks[i][1]
                time2 = peaks[i + j][1]
                delta = time2 - time1
                new_hash = hash((freq1, freq2, delta)) & 0xffffffff 
                hashes.append((new_hash, time1))
    return hashes
#builder fce
def make_up_to_fingerprint(signal):
    spec = get_spectrogram(signal, samples, jump) 
    log_spec = spec_to_spec_log(spec)             
    peaks = search_peaks(log_spec)                
    hashes = make_hash(peaks)                     
    return hashes

# ==========================================
# FINALNA FUNKCIA PRE MATRIX
# ==========================================
def compute_similarity_matrix(query_signals, N_query, known_signals, N_known):
    # 1. Fingerprinty
    fps_query = [make_up_to_fingerprint(query_signals[i]) for i in range(N_query)]
    fps_known = [make_up_to_fingerprint(known_signals[i]) for i in range(N_known)]

    # 2. Databaza
    hash_database = defaultdict(list)
    for song_id in range(N_known):
        for (h, t) in fps_known[song_id]:
            hash_database[h].append((song_id, t))

    # 3. Optimalizacia (Stop Words)
    hash_counts = [len(v) for v in hash_database.values()]
    if hash_counts:
        hashes_to_remove = []
        limit = np.percentile(hash_counts, 99) 
        for h, v in hash_database.items():
            if len(v) > limit:
                hashes_to_remove.append(h)
        for h in hashes_to_remove:
            del hash_database[h]

    # 4. Porovnanie
    similarities = np.zeros((N_query, N_known))
    for i in range(N_query):
        offsets_counter = defaultdict(int)
        for (h, query_t) in fps_query[i]:
            if h in hash_database:  
                for (known_song_id, known_t) in hash_database[h]: 
                    offset = known_t - query_t 
                    offsets_counter[(known_song_id, offset)] += 1

        song_scores = defaultdict(int)
        for (song_id, _), count in offsets_counter.items():
            if count > song_scores[song_id]:
                song_scores[song_id] = count
        
        for song_id, score in song_scores.items():
            similarities[i, song_id] = score

    return similarities

# ==========================================
# VYHODNOTENIE
# ==========================================
def eval(scores, key):
    indices = np.flip(np.argsort(scores), axis=-1) 
    top1acc = np.sum(key == indices[:,0]) / indices.shape[0]
    top5acc = 0
    for ii in range(5):
        top5acc += np.sum(key == indices[:,ii])
    top5acc /=  indices.shape[0]
    return top1acc, top5acc

# ==========================================
# MAIN
# ==========================================
if __name__ == "__main__":
    print("Starting process")
    t_start = time.time()

    # 1. Load KNOWN
    N_known = 706
    no_samples_known = Fs * 10
    known_signals = np.zeros([N_known, no_samples_known])
    load_data(known_signals, "known", N_known, no_samples_known)

    # 2. Load VALID 
    N_valid = 50
    no_samples_valid = Fs * 5
    valid_signals = np.zeros([N_valid, no_samples_valid])
    load_data(valid_signals, "valid", N_valid, no_samples_valid)

    # 3. Vypocdet pre VALID (kvoli presnosti )
    scores_valid = compute_similarity_matrix(valid_signals, N_valid, known_signals, N_known)
    
    # Vypočet presnosti
    key_valid = np.loadtxt("valid/key.txt", delimiter = ',', usecols=(1), dtype ='int')
    top1, top5 = eval(scores_valid, key_valid)

    N_eval = 50
    no_samples_eval = Fs * 5
    eval_signals = np.zeros([N_eval, no_samples_eval])
    load_data(eval_signals, LOGIN, N_eval, no_samples_eval)
    
    scores_eval = compute_similarity_matrix(eval_signals, N_eval, known_signals, N_known)
    np.savetxt("eval.txt", scores_eval)

    t_end = time.time()
    total_time = t_end - t_start

    # Printer pre konzolu
    print("\n" + "="*40)
    print(f" VÝSLEDKY SPRACOVANIA ({LOGIN})")
    print("="*40)
    print(f" Top 1 Accuracy (Valid):  {top1 * 100:.2f} %")
    print(f" Top 5 Accuracy (Valid):  {top5 * 100:.2f} %")
    print(f" Celkový čas behu:        {total_time:.2f} s")
    print("-" * 40)
    print(f" Súbor 'eval.txt' bol úspešne vygenerovaný.")
    print("="*40)


    # Generator grafov
    print("\n--- GENERUJEM GRAFY ---")
    try:
        plt.rcParams['figure.figsize'] = (12, 8)
        
        valid_idx = 0
        key = np.loadtxt("valid/key.txt", delimiter=',', usecols=(1), dtype='int')
        correct_known_idx = key[valid_idx]
        wrong_known_idx = (correct_known_idx + 50) % N_known

        signal_q = valid_signals[valid_idx]
        
        # Graf 1
        spec = get_spectrogram(signal_q, samples, jump)
        log_spec = spec_to_spec_log(spec)
        
        plt.figure()
        plt.subplot(2, 1, 1)
        time_axis = np.linspace(0, len(signal_q) / Fs, len(signal_q))
        plt.plot(time_axis, signal_q)
        plt.title(f"Časový priebeh (Valid #{valid_idx})")
        
        plt.subplot(2, 1, 2)
        plt.imshow(log_spec.T, origin='lower', aspect='auto', cmap='inferno')
        plt.title("Spektrogram")
        plt.tight_layout()
        plt.show()

        # Graf 2 - Peaky
        peaks = search_peaks(log_spec)
        peak_times = [p[1] * jump_size_sec + frame_size_sec/2 for p in peaks]
        peak_freqs = [p[0] * (Fs/2) / 1024 for p in peaks]

        plt.figure(figsize=(12, 6))
        plt.imshow(log_spec.T, origin='lower', aspect='auto', cmap='gray_r', extent=[0, 5, 0, 8000])
        plt.scatter(peak_times, peak_freqs, c='red', marker='x', s=40)
        plt.title("Konštelačná mapa")
        plt.show()

        # Graf 3 - Histogramy


        # Support ufnkcia ktora vypocita rozdiely
        def calculate_offsets(fp_q, fp_db):
            offsets = []
            # Rychla mapa pre DB hashov
            db_map = defaultdict(list)
            for h, t in fp_db:
                db_map[h].append(t)
            
            # Hladame zhodne hashe a pocitamr rozdiel (offset)
            for h, t_q in fp_q:
                if h in db_map:
                    for t_db in db_map[h]:
                        offsets.append(t_db - t_q)
            return offsets

        # 1. Vygenerujeme fingerprinty pre konkretne porovnanie
        fp_q = make_up_to_fingerprint(signal_q)
        fp_correct = make_up_to_fingerprint(known_signals[correct_known_idx])
        fp_wrong = make_up_to_fingerprint(known_signals[wrong_known_idx])

        # 2. Vypocitame offsety
        offsets_correct = calculate_offsets(fp_q, fp_correct)
        offsets_wrong = calculate_offsets(fp_q, fp_wrong)

        # 3. Vykreslenie
        plt.figure(figsize=(14, 6))

        # Graf A: GREEN graf
        plt.subplot(1, 2, 1)
        offsets_sec_correct = np.array(offsets_correct) * jump_size_sec

        plt.hist(offsets_sec_correct, bins=50, color='forestgreen', alpha=0.7)
        plt.title(f"Histogram: Valid #{valid_idx} vs Known #{correct_known_idx} (SPRÁVNY)")
        plt.xlabel("Časový posun (Offset) [s]")
        plt.ylabel("Počet zhodných hashov")
        plt.grid(True, alpha=0.3)

        # Graf B: RED graf
        plt.subplot(1, 2, 2)
        offsets_sec_wrong = np.array(offsets_wrong) * jump_size_sec

        plt.hist(offsets_sec_wrong, bins=50, color='firebrick', alpha=0.7)
        plt.title(f"Histogram: Valid #{valid_idx} vs Known #{wrong_known_idx} (NESPRÁVNY)")
        plt.xlabel("Časový posun (Offset) [s]")
        plt.grid(True, alpha=0.3)
    
        plt.ylim(plt.subplot(1, 2, 1).get_ylim()) 
        plt.tight_layout()
        plt.show()

    except Exception as e:
        print(f"Grafy sa nepodarilo vykreslit!")